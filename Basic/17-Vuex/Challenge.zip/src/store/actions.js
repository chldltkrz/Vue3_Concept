export default {
  login(context) {
    context.commit('doLogin');
  },
  logout(context) {
    context.commit('doLogout');
  },
};

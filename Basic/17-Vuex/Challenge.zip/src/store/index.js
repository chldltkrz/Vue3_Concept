import rootMutations from './mutations.js';
import rootActions from './actions';
import rootGetters from './getters';
import cartIndex from './modules/cart/index.js';
import itemsIndex from './modules/items/index.js';
import { createStore } from 'vuex';

const store = createStore({
  state() {
    return {
      isLoggedIn: false,
    };
  },
  modules: {
    cart: cartIndex,
    item: itemsIndex,
  },
  mutations: rootMutations,
  actions: rootActions,
  getters: rootGetters,
});

export default store;

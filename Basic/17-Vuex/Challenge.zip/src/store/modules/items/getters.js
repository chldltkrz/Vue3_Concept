export default {
  getProducts(state) {
    return state.products;
  },
};

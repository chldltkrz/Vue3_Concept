export default {
  items(state, getters) {
    getters;
    return state.items;
  },
  quantity(state) {
    return state.qty;
  },
  totalSum(state) {
    return state.total;
  },
};

export default {
  doLogin(state) {
    state.isLoggedin = true;
  },
  doLogout(state) {
    state.isLoggedin = false;
  },
};

export default {
  isLoggedIn(state) {
    return state.isLoggedIn;
  },
};

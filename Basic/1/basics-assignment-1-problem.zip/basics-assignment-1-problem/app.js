const app = Vue.createApp({
  data() {
    return {
      myName: "Issac",
      myAge: "<p>30</p>",
      myAge1: "30",
      link: "https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885_960_720.jpg",
    };
  },
  methods: {
    inFiveYear() {
      return Number(this.myAge1) + 5;
    },
    randN() {
      return Math.random();
    },
  },
});

app.mount("#assignment");

Vue.createApp({
  data() {
    return {
      className: "",
      hidden: "visible",
      color: "",
    };
  },
  methods: {
    toggle() {
      if (this.hidden === "visible") {
        this.hidden = "hidden";
      } else if (this.hidden === "hidden") {
        this.hidden = "visible";
      }
    },
  },
}).mount("#assignment");

const app = Vue.createApp({
  data() {
    return {
      alert: "How dare You Pressed the button",
      firstP: "",
      secondP: "",
      confirmed: "",
    };
  },
  methods: {
    pressedButton(e) {
      e.preventDefault();
      alert(this.alert);
    },
    keyDownEventFirst(e) {
      this.firstP = e.target.value;
    },
    keyDownEventSecond(e) {
      this.secondP = e.target.value;
    },
    refresh() {
      this.confirmed = this.secondP;
      secondP = "";
    },
  },
});

app.mount("#assignment");

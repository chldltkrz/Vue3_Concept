<template>
  <form @submit.prevent="setData">
    <label>User Name</label>
    <input type="text" v-model="userName" />
    <label>User Age</label>
    <input type="text" v-model="userAge" />
    <button>SET DATA</button>
  </form>
</template>

<script>
export default {
  data() {
    return {
      userName: "",
      userAge: "",
    };
  },
  emits: ["set"],
  methods: {
    setData() {
      this.$emit("set", this.userName, this.userAge);
    },
  },
};
</script>

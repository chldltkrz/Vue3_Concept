<template>
  <div>
    <h2>Name is : {{ name }}</h2>
    <h3>Age is : {{ age }}</h3>
  </div>
</template>

<script>
export default {
  props: {
    age: { type: String },
    name: { type: String },
  },
  data() {
    return {};
  },
};
</script>

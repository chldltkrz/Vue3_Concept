Vue.createApp({
  data() {
    return {
      task: [],
      enteredTask: "",
      show: true,
      caption: "",
    };
  },
  methods: {
    addTask() {
      this.task.push(this.enteredTask);
    },
    toggle() {
      this.show = !this.show;
    },
  },
}).mount("#assignment");

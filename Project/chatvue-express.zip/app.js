import { ChatCompletionRequestMessageRoleEnum } from "openai";
import chatgpt from "./ChatGPT.js";
import express from "express";
const app = express();
const port = 3334;

const client = chatgpt.ChatGPTClient;
const chatGptMessages = [
  {
    role: ChatCompletionRequestMessageRoleEnum.System,
    content: "You are a helpful assistant.",
  },
  {
    role: ChatCompletionRequestMessageRoleEnum.User,
    content: "Hello world",
  },
];
const result = async function () {
  return await client.respond(chatGptMessages);
};

app.get("/", (req, res) => {
  const x = result().then((n) => n.text);
  console.log(x);
  res.send("SUccess");
});

app.listen(port, () => {
  console.log(`서버가 실행됩니다. http://localhost:${port}`);
});
